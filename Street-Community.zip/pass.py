from werkzeug.security import generate_password_hash

print(generate_password_hash('123'))  # Use this output to insert into your admin table

# 